# Cloudflare Pages Functions Configuration
# This directory contains configuration for Cloudflare Pages Functions
# Functions are automatically deployed from the functions/ directory